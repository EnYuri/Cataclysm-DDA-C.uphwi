# Hentai Mod

Old but not forgotten, finally updated and functional.

YOU MUST DOWNLOAD AND USE THIS VERSION OF CBN (My mod friendly fork) that has the hooks needed. Why special? Because both CDDA and CBN hate modders. But its ok since the repo is fully updated anyways. And should have 0 compatibility issues with other mods, since its just new hooks.

DOWNLOAD -> https://github.com/titusvalid/Cataclysm-BN <- MY FORK

For easy mod/sound/tileset installation i recommend https://github.com/qrrk/Catapult pack.
If you know how to move mods and get them yourself and dont need Catapult then just download the fork and skip to 4.


So in total 
1. Get Catapult, everyone uses it.
2. Using Catapult download BN latest experimental, the mods you want.
3. Get the my fork and drop into "game0" with overwrite.
4. Get the mod and drop into mod folder.
5. Put the folder "Hentai" into your mods, "hentai-mod-master" folder will crash.
6. Done

After dialogue interrupt skips a turn, if you intend to start an "activity" choose either "No" or "Ignore".
You can turn Succubi into pets by taming with collar, then human serum to turn them into NPCs, they dont need regular food - you are food.
Children inherit parents average stats and traits.

99% of new content (speech bites) was written by AI (thats a good thing, it writes better than any modder). No old content was cut. 



[![Join my Discord](https://img.shields.io/discord/1354586195559977050?label=My%20Discord&logo=discord&color=5865F2)](https://discord.gg/Yq2KcCAx)


If you like the mod leave the star on both mine and the guys hooks repos.
And dont forget to spit on CDDA discord troons.
![CDDA hivemind](bump/12.webp)